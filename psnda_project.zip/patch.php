<?php
$file = 'script.js';
$content = file_get_contents($file);

$replacements = [
    // 1. attendance insert
    "const { error } = await supabaseClient.from('attendance').insert([payload]);" => 
    "const response = await fetch(API_BASE + 'attendance', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload) }); const result = await response.json(); const error = response.ok && result.success ? null : new Error('Failed');",
    
    // 2. notifications insert array
    "await supabaseClient.from('notifications').insert(newNotifs);" => 
    "await fetch(API_BASE + 'update/notifications', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(newNotifs) });",
    
    // 3. grades delete
    "const { error } = await supabaseClient.from('grades').delete().eq('id', id);" => 
    "const response = await fetch(API_BASE + 'grades/' + id, {method: 'DELETE'}); const error = response.ok ? null : new Error('Failed');",
    
    // 4. schedule delete
    "const { error } = await supabaseClient.from('schedule').delete().eq('id', id);" => 
    "const response = await fetch(API_BASE + 'schedule/' + id, {method: 'DELETE'}); const error = response.ok ? null : new Error('Failed');",

    // 5. instructors insert
    "const { error } = await supabaseClient.from('instructors').insert([newInstructor]);" => 
    "const response = await fetch(API_BASE + 'update/instructors', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify([newInstructor]) }); const error = response.ok ? null : new Error('Failed');",

    // 6. courses insert
    "const { error } = await supabaseClient.from('courses').insert([newCourse]);" => 
    "const response = await fetch(API_BASE + 'update/courses', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify([newCourse]) }); const error = response.ok ? null : new Error('Failed');",

    // 7. courses update
    "const { error } = await supabaseClient.from('courses').update(updates).eq('id', id);" => 
    "const response = await fetch(API_BASE + 'courses/' + id, { method: 'PUT', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(updates) }); const error = response.ok ? null : new Error('Failed');",

    // 8. schedule update
    "const { error } = await supabaseClient.from('schedule').update(updates).eq('id', id);" => 
    "const response = await fetch(API_BASE + 'update/schedule', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify([{id: id, ...updates}]) }); const error = response.ok ? null : new Error('Failed');",

    // 9. courses insert (Class)
    "const { error } = await supabaseClient.from('courses').insert([newClass]);" => 
    "const response = await fetch(API_BASE + 'update/courses', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify([newClass]) }); const error = response.ok ? null : new Error('Failed');",

    // 10. subjects insert
    "const { error } = await supabaseClient.from('subjects').insert([newSubject]);" => 
    "const response = await fetch(API_BASE + 'update/subjects', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify([newSubject]) }); const error = response.ok ? null : new Error('Failed');",

    // 11. notifications insert (single 1)
    "const { error } = await supabaseClient.from('notifications').insert([newNotif]);" => 
    "const response = await fetch(API_BASE + 'update/notifications', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify([newNotif]) }); const error = response.ok ? null : new Error('Failed');",

    // 12. notifications insert (single 2)
    // already covered by above if exactly matching.

    // 13. schedule insert
    "const { error } = await supabaseClient.from('schedule').insert([newSch]);" => 
    "const response = await fetch(API_BASE + 'update/schedule', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify([newSch]) }); const error = response.ok ? null : new Error('Failed');",

    // 14. grades upsert
    "const { error } = await supabaseClient.from('grades').upsert([newGrade]);" => 
    "const response = await fetch(API_BASE + 'update/grades', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify([newGrade]) }); const error = response.ok ? null : new Error('Failed');",

    // 15. library insert
    "const { error } = await supabaseClient.from('library').insert([newBook]);" => 
    "const response = await fetch(API_BASE + 'update/library', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify([newBook]) }); const error = response.ok ? null : new Error('Failed');",

    // 16. user roles update
    "const { error } = await supabaseClient.from('user_roles').update(updates).eq('email', currentUser.email);" => 
    "const response = await fetch(API_BASE + 'roles/' + encodeURIComponent(currentUser.email), { method: 'PUT', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(updates) }); const error = response.ok ? null : new Error('Failed');",

    // 17. instructors map update img
    "await supabaseClient.from('instructors').update({ img: imgBase64 }).eq('id', inst.id);" => 
    "await fetch(API_BASE + 'instructors/' + inst.id, { method: 'PUT', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({img: imgBase64}) });",

    // 18. settings upsert
    "const { error } = await supabaseClient.from('settings').upsert([{ id: 1, ...newSettings }]);" => 
    "const response = await fetch(API_BASE + 'update/settings', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(newSettings) }); const error = response.ok ? null : new Error('Failed');",

    // 19. accounting insert
    "const { error } = await supabaseClient.from('accounting').insert([newRecord]);" => 
    "const response = await fetch(API_BASE + 'update/accounting', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify([newRecord]) }); const error = response.ok ? null : new Error('Failed');"
];

$originalContent = $content;
foreach ($replacements as $search => $replace) {
    if (strpos($content, $search) !== false) {
        $content = str_replace($search, $replace, $content);
        echo "Replaced: " . htmlspecialchars($search) . "<br>";
    } else {
        echo "NOT FOUND: " . htmlspecialchars($search) . "<br>";
    }
}

if ($content !== $originalContent) {
    file_put_contents($file, $content);
    echo "<hr>File saved successfully.";
} else {
    echo "<hr>No changes made.";
}
?>
