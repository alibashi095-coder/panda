<?php
$zipArchive = new ZipArchive();
$zipFilePath = __DIR__ . '/panda_project_deployment.zip';

$ignoredFiles = [
    'panda_project_deployment.zip', 
    'create_zip.php', 
    'test_hash.php', 
    'update_passwords.php',
    '.antigravityignore',
    '.DS_Store'
];

if ($zipArchive->open($zipFilePath, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
    $dir = new RecursiveDirectoryIterator(__DIR__, RecursiveDirectoryIterator::SKIP_DOTS);
    $iterator = new RecursiveIteratorIterator($dir);

    foreach ($iterator as $file) {
        if ($file->isDir()) {
            continue;
        }

        $filePath = $file->getRealPath();
        $fileName = basename($filePath);
        
        // استثناء الملفات غير المطلوبة
        if (in_array($fileName, $ignoredFiles)) {
            continue;
        }

        // مسار الملف داخل المجلد المضغوط
        $relativePath = substr($filePath, strlen(__DIR__) + 1);
        // Ensure path separators are always forward slashes inside ZIP
        $relativePath = str_replace('\\', '/', $relativePath);
        
        $zipArchive->addFile($filePath, $relativePath);
    }
    
    $zipArchive->close();
    echo "SUCCESS";
} else {
    echo "ERROR";
}
?>
